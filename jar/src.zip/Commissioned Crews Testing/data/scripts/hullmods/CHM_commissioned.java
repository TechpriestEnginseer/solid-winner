package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;

import static data.scripts.plugins.CommissionCheck.*;

public class CHM_commissioned extends BaseHullMod {

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        apply(ship.getVariant(), false);
        ship.getVariant().removeMod(WHILE_IM_LOST);
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return !ship.getVariant().hasHullMod(IN_YOUR_EYES) /*&& !(ship.getParentStation() != null)*/;
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        return "You seem to have a hull mod that prohibits commissioned bonus.";
    }
}


