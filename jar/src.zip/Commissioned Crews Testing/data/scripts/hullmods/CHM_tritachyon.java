package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.HashMap;
import java.util.Map;

public class CHM_tritachyon extends BaseHullMod {
    public static String based = "High Tech";
    public static String based2 = "Tri-Tachyon";
    public static String based3 = "Remnant";
    private static final Map mag = new HashMap();
    static {
        mag.put(HullSize.FRIGATE, 10f);
        mag.put(HullSize.DESTROYER, 10f);
        mag.put(HullSize.CRUISER, 10f);
        mag.put(HullSize.CAPITAL_SHIP, 10f);
    }

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        String manufacturer = stats.getVariant().getHullSpec().getManufacturer();
        if (based.equals(manufacturer) || based2.equals(manufacturer) || based3.equals(manufacturer)) {
            stats.getFluxCapacity().modifyPercent(id, (Float) mag.get(hullSize));
        }
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "10%";
        if (index == 1) return "High-Tech";
        if (index == 2) return based2;
        return null;
    }
}