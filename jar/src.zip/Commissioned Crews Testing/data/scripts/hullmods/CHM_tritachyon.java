package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_tritachyon extends BaseHullMod {
    /*public static String based = "High Tech";
    public static String based2 = "Tri-Tachyon";
    public static String based3 = "Remnant";
    public static String based4 = "Starlight Cabal";*/
    public static final float OVERLOAD_REDUCTION = 17;

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        /*String manufacturer = stats.getVariant().getHullSpec().getManufacturer();
        if (based.equals(manufacturer) || based2.equals(manufacturer) || based3.equals(manufacturer) || based4.equals (manufacturer)) {*/
            stats.getOverloadTimeMod().modifyMult(id, 1f - OVERLOAD_REDUCTION / 100f);
        }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "17%";
        /*if (index == 1) return "High-Tech";
        if (index == 2) return based2;*/
        return null;
    }
}