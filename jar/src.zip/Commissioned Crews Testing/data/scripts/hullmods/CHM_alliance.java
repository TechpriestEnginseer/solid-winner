package data.scripts.hullmods;

import com.fs.starfarer.api.campaign.CampaignUIAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import data.scripts.plugins.CommissionCheck;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CHM_alliance extends BaseHullMod {
    public JSONArray spreadsheet = CommissionCheck.spreadsheet;
    public boolean sneed;
    @Override
    public boolean canBeAddedOrRemovedNow(ShipAPI ship, MarketAPI marketOrNull, CampaignUIAPI.CoreUITradeMode mode) {
        sneed = false;
        if (marketOrNull != null) {
            sneed = true;
            if (ship.getVariant().hasHullMod("CHM_alliance")) {
                for (int i = 0; i < spreadsheet.length(); i++) {
                    try {
                        JSONObject row = spreadsheet.getJSONObject(i);
                        String BigHullMod = row.getString("hullmod_id");
                        if (ship.getVariant().hasHullMod(BigHullMod)){
                            sneed = false;
                            break;
                        }
                    } catch (JSONException ex) {Logger.getLogger(CHM_commissioned.class.getName()).log(Level.SEVERE, null, ex);}
                }
            }
        }
        return sneed;
    }
}
