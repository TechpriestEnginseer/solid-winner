package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.HashMap;
import java.util.Map;

public class CHM_alliance2 extends BaseHullMod {
    public boolean AHHHHHHHHHH;
    private static final Map mag = new HashMap();
    static {
            mag.put(ShipAPI.HullSize.FRIGATE, Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.FRIGATE));
            mag.put(ShipAPI.HullSize.DESTROYER, Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.DESTROYER));
            mag.put(ShipAPI.HullSize.CRUISER, Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.CRUISER));
            mag.put(ShipAPI.HullSize.CAPITAL_SHIP, Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.CAPITAL_SHIP));
	}
    
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        AHHHHHHHHHH = false;
        MutableCharacterStatsAPI statship = ship.getCaptain() == null ? null : ship.getCaptain().getStats();
        if (ship.getVariant().getUnusedOP(statship) >= (int) mag.get(ship.getHullSize())) {
            AHHHHHHHHHH = true;
            ship.getVariant().addMod("CHM_alliance");
        }
        CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
        if (fleet != null) {
            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                MutableCharacterStatsAPI stats = ship.getCaptain() == null ? null : ship.getCaptain().getStats();
                ShipVariantAPI machinegunjackhammer = member.getVariant();
                if (stats != null && machinegunjackhammer.getUnusedOP(stats) >= (int) mag.get(ship.getHullSize())) {
                    AHHHHHHHHHH = true;
                    machinegunjackhammer.addMod("CHM_alliance");
                    member.updateStats();
                }
           }
        }
       if (AHHHHHHHHHH) {Global.getSoundPlayer().playUISound("leadership3", 1f, 1f);}
       ship.getVariant().removeMod("CHM_alliance2");
    }
    
    @Override
    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        if (index == 0) return "" + Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.FRIGATE);
        if (index == 1) return "" + Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.DESTROYER);
        if (index == 2) return "" + Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.CRUISER);
        if (index == 3) return "" + Misc.getMod("CHM_alliance").getCostFor(ShipAPI.HullSize.CAPITAL_SHIP);
        return null;
    }
}