package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.HashMap;
import java.util.Map;

public class CHM_hegemony_xiv extends BaseHullMod {
    private static final Map mag = new HashMap();
    static {
        mag.put(HullSize.FRIGATE, -5f);
        mag.put(HullSize.DESTROYER, -20f);
        mag.put(HullSize.CRUISER, -35f);
        mag.put(HullSize.CAPITAL_SHIP, -50f);
    }
    public static final float ARMOR_BONUS = 50f;

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getArmorBonus().modifyFlat(id, (Float) mag.get(hullSize));
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (!ship.getVariant().hasHullMod("CHM_hegemony")) {
            ship.getVariant().removeMod("CHM_hegemony_xiv");
        }
    }
    
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) ARMOR_BONUS;
        return null;
    }
}
