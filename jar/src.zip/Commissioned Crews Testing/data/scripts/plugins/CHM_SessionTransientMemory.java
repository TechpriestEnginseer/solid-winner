package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.GenericPluginManagerAPI;
import com.fs.starfarer.api.impl.campaign.BaseGenericPlugin;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @Author: SirHartley
 * Free to use, modify and distribute
 */

public class CHM_SessionTransientMemory extends BaseGenericPlugin {

    private transient LinkedHashMap<String, Object> data = new LinkedHashMap<>();

    public CHM_SessionTransientMemory() {
    }

    public static CHM_SessionTransientMemory getInstance() {
        GenericPluginManagerAPI manager = Global.getSector().getGenericPlugins();

        if (!manager.hasPlugin(CHM_SessionTransientMemory.class)) {
            manager.addPlugin(new CHM_SessionTransientMemory(), true);
        }

        return (CHM_SessionTransientMemory) manager.getPluginsOfClass(CHM_SessionTransientMemory.class).get(0);
    }

    public void set(String key, Object object) {
        if (!key.startsWith("$")) {
            throw new RuntimeException("Key " + key + " should start with $");
        } else {
            this.data.put(key, object);
        }
    }

    public Object get(String key) {
        return this.data.get(key);
    }

    public void unset(String key) {
        this.data.remove(key);
    }

    public boolean contains(String key) {
        return this.data.containsKey(key);
    }

    public String getString(String key) {
        return this.data.containsKey(key) ? this.data.get(key).toString() : null;
    }

    public boolean getBoolean(String key) {
        String b = getString(key);
        return b != null && b.toLowerCase().trim().equals("true");
    }

    //this is only for commissioned crews, it's unchecked! Aka - don't use this.
    public Set<String> getStringSet(String key) {
        return this.data.get(key) instanceof Set ? (Set<String>) this.data.get(key) : null;
    }

    //same here
    public Map<String, List<String>> getListMap(String key) {
        return this.data.get(key) instanceof Map ? (Map<String, List<String>>) this.data.get(key) : null;
    }
}
