package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_tritachyon extends BaseHullMod {

        public static final float MAINTENANCE_MULT = 0.90f;
        public static final float EFFECTIVENESS = 20f;

	@Override
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		//stats.getAutofireAimAccuracy().modifyFlat(id, AUTOAIM_BONUS * 0.01f);
                stats.getMinCrewMod().modifyMult(id, MAINTENANCE_MULT);
	}
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
                if (ship.getVariant().hasHullMod("CHM_commission")) {
                    ship.getVariant().removeMod("CHM_commission");
                }
                if (ship.getVariant().hasHullMod("fluxdistributor")) {
                    ship.getVariant().addMod("CHM_tritachyon1");
                }
                if (ship.getVariant().hasHullMod("fluxcoil")) {
                    ship.getVariant().addMod("CHM_tritachyon2");
                }
    }	
      @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) Math.round((1f - MAINTENANCE_MULT) * 100f) + "%";
                if (index == 1) return "" + (int) EFFECTIVENESS + "%";
                if (index == 2) return "Flux Distributor";
                if (index == 3) return "Flux Coil Adjunct";
		return null;
	}
}