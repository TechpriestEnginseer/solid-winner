package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class CHM_pirate extends BaseHullMod {
	public static final float PROFILE_MULT = 0.80f;
        public static final int ARMOR_BONUS = 20;
        public static final float FLUX_HANDLING_MULT = 1.025f;
        public static String based = "XIV Battlegroup";
        
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getSensorProfile().modifyMult(id, PROFILE_MULT);
        if (based.equals(stats.getVariant().getHullSpec().getManufacturer()) || stats.getVariant().hasHullMod("fourteenth") || stats.getVariant().hasHullMod("vayra_pirate_xiv")) {
            stats.getArmorBonus().modifyFlat(id, ARMOR_BONUS);
            stats.getFluxCapacity().modifyMult(id, FLUX_HANDLING_MULT);
            stats.getFluxDissipation().modifyMult(id, FLUX_HANDLING_MULT);
        }
    }	
    
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) ((1.01f - PROFILE_MULT) * 100.0f) + "%";
        return null;
    }
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        if (based.equals(ship.getVariant().getHullSpec().getManufacturer()) || ship.getVariant().hasHullMod("fourteenth") || ship.getVariant().hasHullMod("vayra_pirate_xiv")) {
            tooltip.addPara(Global.getSettings().getString("CHM", "chm_pirates1"), 6f, Misc.getPositiveHighlightColor(), Misc.getRoundedValue(ARMOR_BONUS), Misc.getRoundedValueMaxOneAfterDecimal((FLUX_HANDLING_MULT - 1f)*100f)+"%");
        }
        tooltip.addPara("%s", 6f, Misc.getGrayColor(), Global.getSettings().getString("CHM", "chm_pirates"));
    }
    
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(200,0,0,255);
    }
}