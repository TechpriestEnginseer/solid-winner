package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class CHM_luddic_church extends BaseHullMod {
    public static final float MISSILE_HEALTH_BONUS = 33f;
    public static final float MISSILE_DAMAGE_BONUS = 10f;

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getMissileHealthBonus().modifyPercent(id, MISSILE_HEALTH_BONUS);
        stats.getMissileWeaponDamageMult().modifyPercent(id, MISSILE_DAMAGE_BONUS);
    }
      
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "+" + (int) MISSILE_HEALTH_BONUS  + "%";
        if (index == 1) return "+" + (int) MISSILE_DAMAGE_BONUS  + "%";
        return null;
    }
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        tooltip.addPara("%s", 6f, Misc.getGrayColor(), Global.getSettings().getString("CHM", "chm_luddic_church"));
    }
    
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(76,169,20,255);
    }
}