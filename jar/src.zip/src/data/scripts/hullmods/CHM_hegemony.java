package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import java.util.HashMap;
import java.util.Map;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class CHM_hegemony extends BaseHullMod {
    private static final Map coom = new HashMap();
    static {
        coom.put(HullSize.FIGHTER, 55f);
        coom.put(HullSize.FRIGATE, 55f);
        coom.put(HullSize.DESTROYER, 70f);
        coom.put(HullSize.CRUISER, 85f);
        coom.put(HullSize.CAPITAL_SHIP, 100f);
        coom.put(HullSize.DEFAULT, 55f);
    }
    public static final float ARMOR_BONUS = 50f;
    public static String based = "XIV Battlegroup";

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        if (based.equals(stats.getVariant().getHullSpec().getManufacturer()) || stats.getVariant().hasHullMod("fourteenth")) {
            stats.getArmorBonus().modifyFlat(id, ARMOR_BONUS);
        } else stats.getArmorBonus().modifyFlat(id, (Float) coom.get(hullSize));
    }
    
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + ((Float) coom.get(HullSize.FRIGATE)).intValue();
        if (index == 1) return "" + ((Float) coom.get(HullSize.DESTROYER)).intValue();
        if (index == 2) return "" + ((Float) coom.get(HullSize.CRUISER)).intValue();
        if (index == 3) return "" + ((Float) coom.get(HullSize.CAPITAL_SHIP)).intValue();
        if (index == 4) return "" + (int) ARMOR_BONUS;
        return null;
    }
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        tooltip.addPara("%s", 6f, Misc.getGrayColor(), Global.getSettings().getString("CHM", "chm_hegemony")).italicize();
    }

    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(245,150,30,255);
    }
}
