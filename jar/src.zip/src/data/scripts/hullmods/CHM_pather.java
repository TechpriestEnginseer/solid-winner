package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import java.util.HashMap;
import java.util.Map;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class CHM_pather extends BaseHullMod {
    public static final float DEGRADE_REDUCTION_PERCENT = 15f;
    private static final Map coom = new HashMap();
    static {
        coom.put(HullSize.FIGHTER, 10f);
        coom.put(HullSize.FRIGATE, 25f);
        coom.put(HullSize.DESTROYER, 20f);
        coom.put(HullSize.CRUISER, 15f);
        coom.put(HullSize.CAPITAL_SHIP, 10f);
        coom.put(HullSize.DEFAULT, 10f);
    }
    
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getMaxSpeed().modifyFlat(id, (Float) coom.get(hullSize));
        stats.getCRLossPerSecondPercent().modifyMult(id, 1f - DEGRADE_REDUCTION_PERCENT / 100f);
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + ((Float) coom.get(HullSize.FRIGATE)).intValue();
        if (index == 1) return "" + ((Float) coom.get(HullSize.DESTROYER)).intValue();
        if (index == 2) return "" + ((Float) coom.get(HullSize.CRUISER)).intValue();
        if (index == 3) return "" + ((Float) coom.get(HullSize.CAPITAL_SHIP)).intValue();
        if (index == 4) return "" + (int) DEGRADE_REDUCTION_PERCENT + "%";
        return null;
    }
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        tooltip.addPara("%s", 6f, Misc.getGrayColor(), Global.getSettings().getString("CHM", "chm_pather"));
    }
    
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(150,200,0,255);
    }
}
