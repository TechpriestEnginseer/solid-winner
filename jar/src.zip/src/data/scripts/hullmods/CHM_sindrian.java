package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.util.Misc;

public class CHM_sindrian extends BaseHullMod {
    public static final float TURRET_SPEED_BONUS = 10f;
    public static final float MANEUVER_BONUS = 5f;
	
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
                        stats.getWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
                        stats.getBeamWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
                        stats.getAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
                        stats.getDeceleration().modifyPercent(id, MANEUVER_BONUS);
                        stats.getTurnAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
                        stats.getMaxTurnRate().modifyPercent(id, MANEUVER_BONUS);
        }
    
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
                        if (ship.getCaptain() != null && !ship.getCaptain().isDefault()) {
                            String personality = Misc.lcFirst(ship.getCaptain().getPersonalityAPI().getId());
                            if (personality != null) {
                            switch (personality) {
                                case Personalities.CAUTIOUS:
                                case Personalities.TIMID:
                                    ship.getVariant().addPermaMod("CHM_sindrian1");
                                    ship.getVariant().removePermaMod("CHM_sindrian2");
                                    ship.getVariant().removePermaMod("CHM_sindrian3");
                                    break;
                                case Personalities.STEADY:
                                    if (!ship.getCaptain().isDefault()) {
                                        ship.getVariant().addPermaMod("CHM_sindrian2");
                                        ship.getVariant().removePermaMod("CHM_sindrian1");
                                        ship.getVariant().removePermaMod("CHM_sindrian3");
                                        break;
                                    }
                                    break;
                                case Personalities.AGGRESSIVE:
                                case Personalities.RECKLESS:
                                    ship.getVariant().addPermaMod("CHM_sindrian3");
                                    ship.getVariant().removePermaMod("CHM_sindrian1");
                                    ship.getVariant().removePermaMod("CHM_sindrian2");
                                    break;
                                default:
                                    ship.getVariant().removePermaMod("CHM_sindrian1");
                                    ship.getVariant().removePermaMod("CHM_sindrian2");
                                    ship.getVariant().removePermaMod("CHM_sindrian3");
                                    break;
                                }
                            }
                        }
                if (ship.getVariant().hasHullMod("CHM_commission")) {
                    ship.getVariant().removeMod("CHM_commission");
                }
            }
      @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
                if (index == 0) return "" + (int) MANEUVER_BONUS + "%";
                if (index == 1) return "" + (int) TURRET_SPEED_BONUS + "%";
		return null;
	}
}
