package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class CHM_sindrian extends BaseHullMod {
    public static final float MANEUVER_BONUS = 10f;
    public static float SHIELD_BONUS = 5f;
    public static final float DAMAGE_TO_MODULES_BONUS = 33f;
	
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        if (stats.getVariant().hasTag("amongus1")) {
            stats.getShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_BONUS * 0.01f);
        } else if (stats.getVariant().hasTag("amongus2")) {
            stats.getAcceleration().modifyPercent(id, MANEUVER_BONUS * 6f);
            stats.getDeceleration().modifyPercent(id, MANEUVER_BONUS * 3f);
            stats.getTurnAcceleration().modifyPercent(id, MANEUVER_BONUS * 6f);
            stats.getMaxTurnRate().modifyPercent(id, MANEUVER_BONUS * 3f);
        } else if (stats.getVariant().hasTag("amongus3")) {
            stats.getDamageToTargetEnginesMult().modifyPercent(id, DAMAGE_TO_MODULES_BONUS);
            stats.getDamageToTargetWeaponsMult().modifyPercent(id, DAMAGE_TO_MODULES_BONUS);
        } else {
            stats.getAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
            stats.getDeceleration().modifyPercent(id, MANEUVER_BONUS);
            stats.getTurnAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
            stats.getMaxTurnRate().modifyPercent(id, MANEUVER_BONUS);
        }
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (ship.getCaptain() != null && !ship.getCaptain().isDefault()) {
            String personality = Misc.lcFirst(ship.getCaptain().getPersonalityAPI().getId());
            if (personality != null) {
                switch (personality) {
                    case Personalities.CAUTIOUS:
                    case Personalities.TIMID:
                    ship.getVariant().addTag("amongus1");
                    ship.getVariant().removeTag("amongus2");
                    ship.getVariant().removeTag("amongus3");
                    break;
                    case Personalities.STEADY:
                        if (!ship.getCaptain().isDefault()) {
                            ship.getVariant().removeTag("amongus1");
                            ship.getVariant().addTag("amongus2");
                            ship.getVariant().removeTag("amongus3");
                            break;
                        }
                    break;
                    case Personalities.AGGRESSIVE:
                    case Personalities.RECKLESS:
                    ship.getVariant().removeTag("amongus1");
                    ship.getVariant().removeTag("amongus2");
                    ship.getVariant().addTag("amongus3");
                    break;
                    default:
                    ship.getVariant().removeTag("amongus1");
                    ship.getVariant().removeTag("amongus2");
                    ship.getVariant().removeTag("amongus3");
                    break;
                }
            }
        }  else {                                        
                ship.getVariant().removeTag("amongus1");
                ship.getVariant().removeTag("amongus2");
                ship.getVariant().removeTag("amongus3");
        }
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) MANEUVER_BONUS + "%";
        return null;
    }
 
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        
        if (ship.getVariant().hasTag("amongus1")) {
            tooltip.addPara(Global.getSettings().getString("CHM", "chm_sindrian1"), 6f, Misc.getPositiveHighlightColor(), Misc.getHighlightColor(), Misc.getRoundedValue(SHIELD_BONUS) + "%");
        } //else {tooltip.addPara(Global.getSettings().getString("CHM", "chm_sindrian1"), 6f, Misc.getGrayColor(), Misc.getRoundedValue(SHIELD_BONUS));}
        if (ship.getVariant().hasTag("amongus2")) {
            tooltip.addPara(Global.getSettings().getString("CHM", "chm_sindrian2"), 6f, Misc.getPositiveHighlightColor(), Misc.getHighlightColor(), Misc.getRoundedValue(MANEUVER_BONUS*2f) + "%");
        } //else {tooltip.addPara(Global.getSettings().getString("CHM", "chm_sindrian2"), Misc.getGrayColor(), 6f);}
        if (ship.getVariant().hasTag("amongus3")) {
            tooltip.addPara(Global.getSettings().getString("CHM", "chm_sindrian3"), 6f, Misc.getPositiveHighlightColor(), Misc.getHighlightColor(), Misc.getRoundedValue(DAMAGE_TO_MODULES_BONUS) + "%");
        } //else {tooltip.addPara(Global.getSettings().getString("CHM", "chm_sindrian3"), Misc.getGrayColor(), 6f);}
        tooltip.addPara("%s", 6f, Misc.getGrayColor(), Global.getSettings().getString("CHM", "chm_sindrian"));
    }
    
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(160,0,95,255);
    }
}
