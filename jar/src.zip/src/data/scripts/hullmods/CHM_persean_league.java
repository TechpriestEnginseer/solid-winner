package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

public class CHM_persean_league extends BaseHullMod {
    private static final Map coom = new HashMap();
    public static final float MAINTENANCE_MULT = 0.8f;
    static {
        coom.put(HullSize.FRIGATE, 30f);
        coom.put(HullSize.DESTROYER, 25f);
        coom.put(HullSize.CRUISER, 20f);
        coom.put(HullSize.CAPITAL_SHIP, 15f);
        coom.put(HullSize.DEFAULT, 0f);
        coom.put(HullSize.FIGHTER, 0f);
    }

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        float timeMult = 1f / ((100f + (Float) coom.get(hullSize)) / 100f);
        stats.getFighterRefitTimeMult().modifyMult(id, timeMult);
        stats.getMinCrewMod().modifyMult(id, MAINTENANCE_MULT);
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + ((Float) coom.get(HullSize.FRIGATE)).intValue()  + "%";
        if (index == 1) return "" + ((Float) coom.get(HullSize.DESTROYER)).intValue()  + "%";
        if (index == 2) return "" + ((Float) coom.get(HullSize.CRUISER)).intValue()  + "%";
        if (index == 3) return "" + ((Float) coom.get(HullSize.CAPITAL_SHIP)).intValue()  + "%";
        if (index == 4) return "" + Misc.getRoundedValue(((1f - MAINTENANCE_MULT) * 100f)) + "%";
        return null;
    }
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        tooltip.addPara("%s", 6f, Misc.getGrayColor(), Global.getSettings().getString("CHM", "chm_persean"));
    }
    
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(220,185,20);
    }
}




