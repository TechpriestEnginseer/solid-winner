package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

import java.util.List;

import static data.scripts.plugins.CommissionCheck.*;

public class CHM_alliance2 extends BaseHullMod {
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ShipVariantAPI shipVariant = ship.getVariant();

        //adding the hullmod to this hull, if enough free OP
        MutableCharacterStatsAPI currentShipStats = ship.getCaptain() == null ? null : ship.getCaptain().getStats();
        if (currentShipStats != null && !shipVariant.hasHullMod(IN_YOUR_EYES)) {
            shipVariant.addMod(ALL_DUMB);
            apply(shipVariant, true);
        }
        //same for modules
        if(Global.getSettings().getBoolean("CHM_AutoApplyToModules")) applyHullmodToModulesOfShip(shipVariant, currentShipStats);

        shipVariant.removeMod(COME_RUNNING_DOWN);

        //cycle all other hulls and set bool accordingly
        //apply the respective CC hullmods to the other hulls
        if (cycleOtherHulls()) {
            apply(true);
        }
    }

    private boolean cycleOtherHulls(){
        boolean appliedAllianceHullmods = false;

        //adding the hullmod to every other hull with enough free OP
        CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
        if (fleet != null) {
            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {

                MutableCharacterStatsAPI stats = member.getCaptain() == null ? null : member.getCaptain().getStats();
                ShipVariantAPI memberVariant = member.getVariant();

                if (stats != null
                        && !member.getVariant().hasHullMod(IN_YOUR_EYES)) {

                    appliedAllianceHullmods = true;
                    memberVariant.addMod(ALL_DUMB);
                }

                //modules again
                if(Global.getSettings().getBoolean("CHM_AutoApplyToModules")) applyHullmodToModulesOfShip(memberVariant, stats);
            }
        }

        return appliedAllianceHullmods;
    }

    private void applyHullmodToModulesOfShip(ShipVariantAPI shipVariant, MutableCharacterStatsAPI stats){
        if(stats == null) return;

        List<String> modules = shipVariant.getModuleSlots();
        if(!modules.isEmpty()) {
            for (String s : modules) {
                ShipVariantAPI moduleVariant = shipVariant.getModuleVariant(s);
                if (!moduleVariant.hasHullMod(IN_YOUR_EYES)) {
                    moduleVariant.addMod(ALL_DUMB);
                }
            }
        }
    }

    @Override
    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        return null;
    }
}