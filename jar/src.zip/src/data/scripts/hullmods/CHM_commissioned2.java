package data.scripts.hullmods;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;

public class CHM_commissioned2 extends BaseHullMod {
        @Override
	public boolean isApplicableToShip(ShipAPI ship) {
		return !ship.getVariant().hasHullMod("CHM_commission");
	}
        @Override
	public String getUnapplicableReason(ShipAPI ship) {
		return "You're trying to install a Commissioned Bonus first of all...";
	}
}


