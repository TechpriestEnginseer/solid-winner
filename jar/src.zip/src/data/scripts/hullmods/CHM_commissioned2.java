package data.scripts.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;

public class CHM_commissioned2 extends BaseHullMod {

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        return "Trying to install this on a module? First of all...";
    }
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (ship.getVariant().getPermaMods().contains("CHM_commission2")) {ship.getVariant().removePermaMod("CHM_commission2"); Global.getSoundPlayer().playUISound("ui_refit_slot_cleared_large", 1f, 1f);}
    }
}