package data.scripts.plugins;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.SharedUnlockData;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.codex.CodexDataV2;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.ALL_TECHS;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.ALL_TYPES;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.DMODS;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.INTRINSIC;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.getHullmodEntryId;
import com.fs.starfarer.api.impl.codex.CodexDialogAPI;
import com.fs.starfarer.api.impl.codex.CodexEntryPlugin;
import com.fs.starfarer.api.impl.codex.CodexEntryV2;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.VariantSource;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TagDisplayAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.UIPanelAPI;
import com.fs.starfarer.api.util.CountingMap;
import com.fs.starfarer.api.util.Misc;
import exerelin.campaign.AllianceManager;
import exerelin.campaign.alliances.Alliance;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.*;
import lunalib.lunaSettings.LunaSettings;

/**
 * @Author SirHartley <-- have sex originally
 * for version 0.9.1a
 * <p>
 * Impl with option for a unlimited hullmods in the same list
 */

public class CommissionCheck extends BaseModPlugin {

    private static org.apache.log4j.Logger log = Global.getLogger(CommissionCheck.class);
    public static final String FACTION_HULLMOD_MAP = "$chm_fm_1";
    public static final String ALL_HULLMOD_IDS = "$chm_allHullMods";
    public static final String YOU_DO_ME = "CHM_alliance";
    public static final String COME_RUNNING_DOWN = "CHM_alliance2";
    public static final String ALL_DUMB= "CHM_alliance3";
    public static final String WHILE_IM_LOST = "CHM_commission";
    public static final String IN_YOUR_EYES = "CHM_commission2";
    
    @Override
    public void onApplicationLoad() throws JSONException, IOException {
        Map<String, List<String>> factionHullmodMap = getCSVMap("data/config/CommissionBonus/TechpriestCommission.csv","hullmod_id","faction_id","timid_commissioned_hull_mods");
        Set<String> allHullModIds = new HashSet<>();
        for (Map.Entry<String, List<String>> e : factionHullmodMap.entrySet())
            extractListForKey(e.getKey(), factionHullmodMap, allHullModIds);
        Iterator iter = allHullModIds.iterator();
        while (iter.hasNext()) {
            Global.getSettings().getHullModSpec(iter.next().toString()).addUITag(Global.getSettings().getString("CHM", "chm_commissioned_crew"));
        }
    }

    @Override
    public void onAboutToLinkCodexEntries() {
        super.onAboutToLinkCodexEntries();
        CodexEntryV2 hullmods = new CodexEntryV2("chm_hullmods", Global.getSettings().getString("CHM", "helphooray"), "graphics/hullmods/chm_unified_alliance.png") {
                public boolean hasCustomDetailPanel() {return true;}
                public boolean hasDetail() {return true;}
                public void createCustomDetail(CustomPanelAPI panel, UIPanelAPI relatedEntries, CodexDialogAPI codex) {
                                    float opad = 10f;
                                    float pad = 5f;
                                    float width = panel.getPosition().getWidth();
                                    float initPad = 0f;
                                    float horzBoxPad = 30f;
                                    float tw = width - 290f - opad - horzBoxPad + 10f;
                                    TooltipMakerAPI text = panel.createUIElement(tw, 0, false);
                                    text.setParaInsigniaLarge();
                                    text.addPara(Global.getSettings().getString("CHM", "help1title"), initPad);
                                    text.setParaFontDefault();
                                    text.addPara(Global.getSettings().getString("CHM", "help1a"), pad);
                                    text.addPara(Global.getSettings().getString("CHM", "help1b"), pad, Misc.getHighlightColor(), Global.getSettings().getString("CHM", "help1ba"), Global.getSettings().getString("CHM", "help1bb"));
                                    text.addPara(Global.getSettings().getString("CHM", "help1c"), pad, Misc.getHighlightColor(), Global.getSettings().getString("CHM", "help1ca"), Global.getSettings().getString("CHM", "help1cb"));
                                    panel.updateUIElementSizeAndMakeItProcessInput(text);

                                    UIPanelAPI box = panel.wrapTooltipWithBox(text);
                                    panel.addComponent(box).inTL(0f, 0f);
                };
			@Override
			public boolean hasTagDisplay() {
				return true;
			}
			@Override
			public void configureTagDisplay(TagDisplayAPI tags) {
				CountingMap<String> techs = new CountingMap<String>();
				CountingMap<String> types = new CountingMap<String>();
				int total = 0;
				
				for (CodexEntryPlugin curr : getChildren()) {
					if (!(curr.getParam() instanceof HullModSpecAPI)) continue;
					if (!curr.isVisible() || curr.isLocked() || curr.skipForTags()) continue;
					HullModSpecAPI spec = (HullModSpecAPI) curr.getParam();
				
					techs.add(spec.getManufacturer());
					for (String type : spec.getUITags()) {
						types.add(type);
					}
					total++;
				}

				float opad = 10f;
				
				tags.beginGroup(false, ALL_TECHS);
				List<String> keys = new ArrayList<String>(techs.keySet());
				Collections.sort(keys);
				for (String tech : keys) {
					tags.addTag(tech, tech, techs.getCount(tech));
				}
				tags.setTotalOverrideForCurrentGroup(total);
				tags.addGroup(0f);
                                tags.checkAll();
				
				
				tags.beginGroup(false, ALL_TYPES);
				keys = new ArrayList<String>(types.keySet());
				Collections.sort(keys);
				for (String type : keys) {
					tags.addTag(type, type, types.getCount(type));
				}
				tags.setTotalOverrideForCurrentGroup(total);
				tags.addGroup(opad * 1f);
                                tags.checkAll();
				//tags.check(Global.getSettings().getString("CHM", "chm_commissioned_crew"));
			}
			
		};
                {List<HullModSpecAPI> specs = Global.getSettings().getAllHullModSpecs();
		for (final HullModSpecAPI spec : specs) {
			if (spec.isHiddenEverywhere()) continue;
			if (spec.hasTag(Tags.HIDE_IN_CODEX)) continue;

			CodexEntryV2 curr = new CodexEntryV2(getHullmodEntryId(spec.getId()), 
				spec.getDisplayName(), spec.getSpriteName(), spec) {
					@Override
					public void createTitleForList(TooltipMakerAPI info, float width, ListMode mode) {
						info.addPara(spec.getDisplayName(), Misc.getBasePlayerColor(), 0f);
						if (mode == ListMode.RELATED_ENTRIES) {
							info.addPara("Hullmod", Misc.getGrayColor(), 0f);
						}
					}
					@Override
					public boolean isVignetteIcon() {
						return true;
					}
					
					@Override
					public boolean matchesTags(Set<String> tags) {
						if (!tags.contains(spec.getManufacturer())) {
							return false;
						}
						
						if (tags.contains(ALL_TYPES)) return true;
						
						boolean hasATag = false;
						for (String tag : spec.getUITags()) {
							if (tags.contains(tag)) hasATag = true;
						}
						if (spec.hasTag(Tags.HULLMOD_DMOD) && tags.contains(DMODS)) {
							hasATag = true;
						}
						if (spec.isHidden() && !spec.hasTag(Tags.HULLMOD_DMOD) && tags.contains(INTRINSIC)) {
							hasATag = true;
						}
						if (!hasATag) return false;
						
						return true;
					}
					
					@Override
					public Set<String> getUnlockRelatedTags() {
						return spec.getTags();
					}
					
					@Override
					public boolean isUnlockedIfRequiresUnlock() {
						return SharedUnlockData.get().isPlayerAwareOfHullmod(spec.getId());
					}
			};
			if (spec.hasUITag(Global.getSettings().getString("CHM", "chm_commissioned_crew"))) {hullmods.addChild(curr);}
			
		}
	}
        CodexDataV2.ROOT.addChild(hullmods);
        CodexDataV2.rebuildIdToEntryMap();
    }

    @Override
    public void onGameLoad(boolean newGame) {
        super.onGameLoad(newGame);
        //get the first faction/hullmod map, and store it in the transient memory
        Map<String, List<String>> factionHullmodMap = getCSVMap("data/config/CommissionBonus/TechpriestCommission.csv","hullmod_id","faction_id","timid_commissioned_hull_mods");
        //make the pure CC hullmod set here so we only have to do it twice
        Set<String> allHullModIds = new HashSet<>();
        for (Map.Entry<String, List<String>> e : factionHullmodMap.entrySet())
            extractListForKey(e.getKey(), factionHullmodMap, allHullModIds);
        //play em both into memory
        CHM_SessionTransientMemory transientMemory = CHM_SessionTransientMemory.getInstance();
        transientMemory.set(FACTION_HULLMOD_MAP, factionHullmodMap);
        transientMemory.set(ALL_HULLMOD_IDS, allHullModIds);
        Global.getSector().addTransientListener(new CommissionCheckMarket());
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_commission")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_commission");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_commission2")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_commission2");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_alliance")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_alliance");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_alliance2")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_alliance2");
    }
    
    @Override
    public void afterGameSave() {
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_commission")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_commission");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_commission2")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_commission2");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_alliance")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_alliance");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("CHM_alliance2")) Global.getSector().getPlayerFaction().addKnownHullMod("CHM_alliance2");
    }
    

    @Override
    public void beforeGameSave() {
        Global.getSector().getPlayerFaction().removeKnownHullMod("CHM_commission");
        Global.getSector().getPlayerFaction().removeKnownHullMod("CHM_commission2");
        Global.getSector().getPlayerFaction().removeKnownHullMod("CHM_alliance");
        Global.getSector().getPlayerFaction().removeKnownHullMod("CHM_alliance2");
    }
    
    @Override
    public void onNewGameAfterTimePass() {
        for (FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
            member.getVariant().setSource(VariantSource.REFIT); //This is to prevent the starting ship not getting CC buff.
        }
    }

    private static class CommissionCheckMarket extends BaseCampaignEventListener {
        private CommissionCheckMarket() {
            super(false);
        }

        @Override
        public void reportPlayerOpenedMarket(MarketAPI market) {
            if (!market.getFactionId().equals(Factions.NEUTRAL)) {
                apply(false);
            }
        }
    }

    public static void apply(boolean allianceSound) {
        apply(null, allianceSound);
    }

    public static void apply(ShipVariantAPI var, boolean allianceSound) {
        boolean ccModApplied = false;
        if (Global.getSector().getPlayerFleet() != null) {
            List<FleetMemberAPI> playerFleetList = Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy();
            String commissionedFactionId = Misc.getCommissionFactionId() != null ? Misc.getCommissionFactionId() : "player";
            CommissionData data = new CommissionData(commissionedFactionId);
            if (var == null) {
                //iterate through all fleet members - remove any excess CC hullmods if present, apply the correct ones.
                for (FleetMemberAPI member : playerFleetList) {
                    boolean done = cycleVariantWithModules(member.getVariant(), data);
                    if (!ccModApplied) ccModApplied = done;
                    member.updateStats();
                }
            } else {
                ccModApplied = cycleVariantWithModules(var, data);
            }
            if (ccModApplied && (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_commissioned_hull_mods", "CHM_EnableSoundOnApplication") : Global.getSettings().getBoolean("CHM_EnableSoundOnApplication"))) {
                if (allianceSound) Global.getSoundPlayer().playUISound("chm_alliancesuccess", 1f, 1f);
                else Global.getSoundPlayer().playUISound("chm_commissionsuccess", 1f, 1f);
            }
        }
    }

    public static boolean cycleVariantWithModules(ShipVariantAPI shipVariant, CommissionData data) {
        boolean ccModApplied = cycleVariant(shipVariant, data);
        if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_commissioned_hull_mods", "CHM_AutoApplyToModules") : !Global.getSettings().getBoolean("CHM_AutoApplyToModules")) return ccModApplied;
        boolean ccModAppliedToModule;
        List<String> modules = shipVariant.getModuleSlots();
        if (!modules.isEmpty()) {
            for (String s : modules) {
                if (shipVariant.getModuleVariant(s).getHullSize() == HullSize.FIGHTER) continue;
                ccModAppliedToModule = cycleVariant(shipVariant.getModuleVariant(s), data);
                if (!ccModApplied) ccModApplied = ccModAppliedToModule;
            }
        }
        return ccModApplied;
    }

    public static boolean cycleVariant(ShipVariantAPI shipVariant, CommissionData data) {
        boolean ccModApplied = false;
        boolean ccHullmodsBlocked = shipVariant.hasHullMod(IN_YOUR_EYES);
        boolean needsAllianceMods = shipVariant.hasHullMod(ALL_DUMB);
        Set<String> currentHullmodSet = new HashSet<>(shipVariant.getHullMods());
        Set<String> CoomHullmods = data.getAllHullmodSetCopy();
        //if it has no current commission hullmods, it needs them
        Set<String> requiredHullmodIds = Collections.disjoint(data.getCommissionedHullmodSetCopy(), currentHullmodSet) ? data.getCommissionedHullmodSetCopy() : new HashSet<String>();
        CoomHullmods.removeAll(data.getCommissionedHullmodSetCopy());
        //if it has no current faction commission hullmods, it needs them if enabled
        if (needsAllianceMods) {
            for (List<String> factionHullmodList : data.getAlliedFactionHullmodListMapCopy().values()) {
                if (Collections.disjoint(factionHullmodList, currentHullmodSet)) requiredHullmodIds.addAll(factionHullmodList);
                CoomHullmods.removeAll(factionHullmodList);
            }
        }
        boolean hasAllRequiredHullmods = currentHullmodSet.containsAll(requiredHullmodIds);
        boolean hasNoCoomHullmods = Collections.disjoint(CoomHullmods, currentHullmodSet);
        //remove all disallowed mods if there are any
        if (!hasNoCoomHullmods) {
            for (String shipHullMod : currentHullmodSet) {
                if (CoomHullmods.contains(shipHullMod)) shipVariant.removeMod(shipHullMod);
            }
        }
        //apply the correct mods if any are missing, unless blocked
        if (!ccHullmodsBlocked && !hasAllRequiredHullmods) {
            requiredHullmodIds.removeAll(currentHullmodSet);
            for (String hullmodId : requiredHullmodIds) {
                shipVariant.addMod(hullmodId);
                ccModApplied = true;
            }
        }
        return ccModApplied;
    }
    
    public static Map<String, List<String>> getRequiredHullmodistMapForAllies(String forFactionId, Map<String, List<String>> factionHullmodMap) {
        Set<String> alliedFactionList = getAlliedFactionIdList(forFactionId);
        //adding the required IDs onto a list
        Map<String, List<String>> requiredHullmodIds = new HashMap<>();
        for (String factionId : alliedFactionList)
            if (factionHullmodMap.get(factionId) != null) {
                requiredHullmodIds.put(factionId, factionHullmodMap.get(factionId));
        }
        return requiredHullmodIds;
    }

    private static Set<String> getAlliedFactionIdList(String forFactionId) {
        Alliance alliance_1 = AllianceManager.getFactionAlliance(forFactionId);
        return alliance_1 != null ? alliance_1.getMembersCopy() : new HashSet<String>();
    }

    public static void extractListForKey(String key, Map<String, List<String>> fromMap, Set<String> toSet) {
        if (fromMap.containsKey(key)) toSet.addAll(fromMap.get(key));
    }

    //getting a merged map from all .csv files in the specified path.
    public static Map<String, List<String>> getCSVMap(String path, String masterColumnId, String subColumnId, String masterModId) {
        Map<String, List<String>> csvMap = new HashMap<>();

        try {
            JSONArray spreadsheet = Global.getSettings().getMergedSpreadsheetDataForMod(masterColumnId, path, masterModId);

            for (int i = 0; i < spreadsheet.length(); i++) {
                JSONObject row = spreadsheet.getJSONObject(i);
                String Ohyesmasterme = row.getString(masterColumnId);
                String Ohyesimasub = row.getString(subColumnId);

                if (csvMap.containsKey(Ohyesimasub)) csvMap.get(Ohyesimasub).add(Ohyesmasterme);
                else csvMap.put(Ohyesimasub, new ArrayList<>(Collections.singletonList(Ohyesmasterme)));
            }
        } catch (IOException | JSONException ex) {
            log.error(ex);
        }

        return csvMap;
    }

    private static class CommissionData {
        public Map<String, List<String>> alliedFactionHullmodListMap;
        public Set<String> allHullmodSet;
        public Set<String> commissionedHullmodSet;

        public CommissionData(String commissionedFactionId) {
            boolean HaveNex = Global.getSettings().getModManager().isModEnabled("nexerelin");
            Map<String, List<String>> allFactionHullmodListMap = CHM_SessionTransientMemory.getInstance().getListMap(FACTION_HULLMOD_MAP);
            this.alliedFactionHullmodListMap = HaveNex ? getRequiredHullmodistMapForAllies(commissionedFactionId, allFactionHullmodListMap) : new HashMap<String, List<String>>();
            this.allHullmodSet = convertToSet(allFactionHullmodListMap);
            this.commissionedHullmodSet = new HashSet<>();
            extractListForKey(commissionedFactionId, allFactionHullmodListMap, commissionedHullmodSet);
        }

        public Map<String, List<String>> getAlliedFactionHullmodListMapCopy() {
            return new HashMap<>(alliedFactionHullmodListMap);
        }

        public Set<String> getAllHullmodSetCopy() {
            return new HashSet<>(allHullmodSet);
        }

        public Set<String> getCommissionedHullmodSetCopy() {
            return new HashSet<>(commissionedHullmodSet);
        }

        private Set<String> convertToSet(Map<String, List<String>> listMap) {
            Set<String> s = new HashSet<>();
            for (List<String> l : listMap.values()) s.addAll(l);
            return s;
        }
    }
}