package data.scripts.plugins;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CommissionCheck extends BaseModPlugin {
   public JSONArray spreadsheet;

    public CommissionCheck() {
        try {
            this.spreadsheet = Global.getSettings().getMergedSpreadsheetDataForMod("faction_id", "data/config/CommissionBonus/TechpriestCommission.csv", "timid_commissioned_hull_mods");
        
        }
        catch (JSONException ex) {Logger.getLogger(CommissionCheck.class.getName()).log(Level.SEVERE, null, ex);
}
        catch (IOException ex) {
            Logger.getLogger(CommissionCheck.class.getName()).log(Level.SEVERE, null, ex);
        }
    };
    @Override
    public void onGameLoad(boolean newGame)
    {
        Global.getSector().addTransientListener(new CommissionCheckMarket());
    }

    private class CommissionCheckMarket extends BaseCampaignEventListener {
        public CommissionCheckMarket() {
            super(false);
        }

        @Override
        public void reportPlayerOpenedMarket(MarketAPI market) {
        if (!market.getFactionId().equals(Factions.NEUTRAL)) {
            boolean NewChange = false;
            if (Misc.getCommissionFactionId() != null) {
                for (int i = 0; i < spreadsheet.length(); i++) {
                    try {
                        JSONObject row = spreadsheet.getJSONObject(i);
                        String BigFactionEnergy = row.getString("faction_id");
                        String BigHullMod = row.getString("hullmod_id");
                        if (BigFactionEnergy.equals(Misc.getCommissionFactionId())) {
                            CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
                            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                                ShipVariantAPI ship = member.getVariant();
                                if (!ship.hasHullMod(BigHullMod) && !ship.hasHullMod("CHM_commission2")) {
                                    ship.addMod(BigHullMod);
                                    NewChange = true;
                                }
                                    member.updateStats();
                                }
                            }
                        } catch (JSONException ex) {Logger.getLogger(CommissionCheck.class.getName()).log(Level.SEVERE, null, ex);}
                    }
                }
                if (NewChange) {Global.getSoundPlayer().playUISound("leadership2", 1f, 1f);}
            }
        }
    }
}