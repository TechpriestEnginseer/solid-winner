package data.scripts.plugins;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import exerelin.campaign.AllianceManager;

public class CommissionCheck extends BaseModPlugin {
    public static JSONArray spreadsheet;
    boolean NewChange;
    boolean NewChange2;

    public CommissionCheck() {
        try {this.spreadsheet = Global.getSettings().getMergedSpreadsheetDataForMod("faction_id", "data/config/CommissionBonus/TechpriestCommission.csv", "timid_commissioned_hull_mods");}
        catch (JSONException ex) {Logger.getLogger(CommissionCheck.class.getName()).log(Level.SEVERE, null, ex);}
        catch (IOException ex) {Logger.getLogger(CommissionCheck.class.getName()).log(Level.SEVERE, null, ex);}
    };
    
    boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
    @Override
    public void onGameLoad(boolean newGame) {
        if (haveNexerelin){Global.getSector().addTransientListener(new NexCommissionCheckMarket());}
        if (!haveNexerelin){Global.getSector().addTransientListener(new CommissionCheckMarket());}
    }

    private class NexCommissionCheckMarket extends BaseCampaignEventListener {
        public NexCommissionCheckMarket() {super(false);}
        @Override
        public void reportPlayerOpenedMarket(MarketAPI market) {
            if (!market.getFactionId().equals(Factions.NEUTRAL)) {
                NewChange = false;
                NewChange2 = false;
                CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
                for (int i = 0; i < spreadsheet.length(); i++) {
                    try {
                        JSONObject row = spreadsheet.getJSONObject(i);
                        String BigFactionEnergy = row.getString("faction_id");
                        String BigHullMod = row.getString("hullmod_id");
                        String EverybodyWantsToRuleTheWorld = "player";
                        if (Misc.getCommissionFactionId() != null) {EverybodyWantsToRuleTheWorld = Misc.getCommissionFactionId();}
                        if (BigFactionEnergy.equals(EverybodyWantsToRuleTheWorld) || AllianceManager.areFactionsAllied(EverybodyWantsToRuleTheWorld, BigFactionEnergy)) {
                            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                                ShipVariantAPI ship = member.getVariant();
                                if (!ship.hasHullMod(BigHullMod) && !ship.hasHullMod("CHM_commission2") && BigFactionEnergy.equals(Misc.getCommissionFactionId())) {
                                    ship.addMod(BigHullMod);
                                    NewChange = true;
                                }
                                if (!ship.hasHullMod(BigHullMod) && ship.hasHullMod("CHM_alliance") && !ship.hasHullMod("CHM_commission2")) {
                                    NewChange2 = true;
                                    ship.addMod(BigHullMod);
                                }
                                member.updateStats();
                            }
                        } else {
                            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                                member.getVariant().removeMod(BigHullMod);
                                member.updateStats();
                            }
                        }
                    } catch (JSONException ex) {Logger.getLogger(CommissionCheck.class.getName()).log(Level.SEVERE, null, ex);}
                }
                if (NewChange) {Global.getSoundPlayer().playUISound("leadership2", 1f, 0.5f);}
                if (NewChange2) {Global.getSoundPlayer().playUISound("leadership3", 1f, 0.5f);}
            }
        }
    }
    
    private class CommissionCheckMarket extends BaseCampaignEventListener {
        public CommissionCheckMarket() {
            super(false);
        }
        @Override
        public void reportPlayerOpenedMarket(MarketAPI market) {
            if (!market.getFactionId().equals(Factions.NEUTRAL)) {
                NewChange = false;
                CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
                for (int i = 0; i < spreadsheet.length(); i++) {
                    try {
                        JSONObject row = spreadsheet.getJSONObject(i);
                        String BigFactionEnergy = row.getString("faction_id");
                        String BigHullMod = row.getString("hullmod_id");
                        if (BigFactionEnergy.equals(Misc.getCommissionFactionId())) {
                            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                                ShipVariantAPI ship = member.getVariant();
                                if (!ship.hasHullMod(BigHullMod) && !ship.hasHullMod("CHM_commission2")) {
                                    ship.addMod(BigHullMod);
                                    NewChange = true;
                                }
                                member.updateStats();
                            }
                        } else {
                            for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                                ShipVariantAPI ship = member.getVariant();
                                ship.removeMod(BigHullMod);
                                member.updateStats();
                            }
                        }
                    } catch (JSONException ex) {Logger.getLogger(CommissionCheck.class.getName()).log(Level.SEVERE, null, ex);}
                }
                if (NewChange) {Global.getSoundPlayer().playUISound("leadership2", 1f, 0.5f);}
            }
        }
    }
}