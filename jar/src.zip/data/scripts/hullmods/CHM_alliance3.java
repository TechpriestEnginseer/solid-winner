package data.scripts.hullmods;

import com.fs.starfarer.api.campaign.CampaignUIAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import data.scripts.plugins.CHM_SessionTransientMemory;
import data.scripts.plugins.CommissionCheck;

import java.util.Collections;

import static data.scripts.plugins.CommissionCheck.ALL_DUMB;

public class CHM_alliance3 extends BaseHullMod {

    @Override
    public boolean canBeAddedOrRemovedNow(ShipAPI ship, MarketAPI marketOrNull, CampaignUIAPI.CoreUITradeMode mode) {
        boolean canAddOrRemove = false;

        if (marketOrNull != null) {
            canAddOrRemove = true;

            ShipVariantAPI var = ship.getVariant();
            if (var.hasHullMod(ALL_DUMB)) {
                return Collections.disjoint(var.getHullMods(), CHM_SessionTransientMemory.getInstance().getStringSet(CommissionCheck.ALL_HULLMOD_IDS));
            }
        }

        return canAddOrRemove;
    }

    @Override
    public String getCanNotBeInstalledNowReason(ShipAPI ship, MarketAPI marketOrNull, CampaignUIAPI.CoreUITradeMode mode) {
        if(!super.canBeAddedOrRemovedNow(ship, marketOrNull, mode)) return super.getCanNotBeInstalledNowReason(ship, marketOrNull, mode);
        else return "Can not be uninstalled while Commissioned Crews Hullmods are active.";
    }
}