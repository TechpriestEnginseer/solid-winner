package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

public class CHM_luddic_church extends BaseHullMod {
    public static final float MISSILE_HEALTH_BONUS = 25f;
    private static final Map coom = new HashMap();
    static {
        coom.put(HullSize.FIGHTER, 30f);
        coom.put(HullSize.FRIGATE, 30f);
        coom.put(HullSize.DESTROYER, 25f);
        coom.put(HullSize.CRUISER, 20f);
        coom.put(HullSize.CAPITAL_SHIP, 15f);
        coom.put(HullSize.DEFAULT, 15f);
    }

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getMissileHealthBonus().modifyPercent(id, MISSILE_HEALTH_BONUS);
        stats.getMissileShieldDamageTakenMult().modifyPercent(id, (Float) coom.get(hullSize));
    }
      
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "+" + (int) MISSILE_HEALTH_BONUS  + "%";
        if (index == 1) return "" + ((Float) coom.get(HullSize.FRIGATE)).intValue()  + "%";
        if (index == 2) return "" + ((Float) coom.get(HullSize.DESTROYER)).intValue()  + "%";
        if (index == 3) return "" + ((Float) coom.get(HullSize.CRUISER)).intValue()  + "%";
        if (index == 4) return "" + ((Float) coom.get(HullSize.CAPITAL_SHIP)).intValue()  + "%";
        return null;
    }
    
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(76,169,20,255);
    }
}