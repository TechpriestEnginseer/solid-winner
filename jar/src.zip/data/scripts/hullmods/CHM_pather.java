package data.scripts.hullmods;

import java.util.HashMap;
import java.util.Map;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_pather extends BaseHullMod {
    public static final float DEGRADE_REDUCTION_PERCENT = 15f;
    private static final Map coom = new HashMap();
    static {
        coom.put(HullSize.FRIGATE, 25f);
        coom.put(HullSize.DESTROYER, 20f);
        coom.put(HullSize.CRUISER, 15f);
        coom.put(HullSize.CAPITAL_SHIP, 10f);
        coom.put(HullSize.DEFAULT, 10f);
    }
    
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getMaxSpeed().modifyFlat(id, (Float) coom.get(hullSize));
        stats.getCRLossPerSecondPercent().modifyMult(id, 1f - DEGRADE_REDUCTION_PERCENT / 100f);
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + ((Float) coom.get(HullSize.FRIGATE)).intValue();
        if (index == 1) return "" + ((Float) coom.get(HullSize.DESTROYER)).intValue();
        if (index == 2) return "" + ((Float) coom.get(HullSize.CRUISER)).intValue();
        if (index == 3) return "" + ((Float) coom.get(HullSize.CAPITAL_SHIP)).intValue();
        if (index == 4) return "" + (int) DEGRADE_REDUCTION_PERCENT + "%";;
        return null;
    }
}
