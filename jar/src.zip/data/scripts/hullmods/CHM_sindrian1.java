package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_sindrian1 extends BaseHullMod {
    public static final float SHIELD_DAMAGE_REDUCTION = 5f;
	
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
            stats.getShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_DAMAGE_REDUCTION / 100f);
        }
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
                if (!ship.getVariant().hasHullMod("CHM_sindrian")) {
                    ship.getVariant().removePermaMod("CHM_sindrian1");
                }
            }
      @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
                if (index == 0) return "" + (int) SHIELD_DAMAGE_REDUCTION + "%";
		return null;
	}
}
