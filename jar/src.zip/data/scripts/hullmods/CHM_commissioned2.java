package data.scripts.hullmods;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;

public class CHM_commissioned2 extends BaseHullMod {

    /*@Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return !(ship.getParentStation() != null);
    }*/
    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        return "Trying to install this on a module? First of all...";
    }
}