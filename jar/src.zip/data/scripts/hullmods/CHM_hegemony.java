package data.scripts.hullmods;

import java.util.HashMap;
import java.util.Map;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_hegemony extends BaseHullMod {
    private static final Map coom = new HashMap();
    static {
        coom.put(HullSize.FRIGATE, 55f);
        coom.put(HullSize.DESTROYER, 70f);
        coom.put(HullSize.CRUISER, 85f);
        coom.put(HullSize.CAPITAL_SHIP, 100f);
        coom.put(HullSize.DEFAULT, 55f);
    }

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getArmorBonus().modifyFlat(id, (Float) coom.get(hullSize));
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (ship.getVariant().hasHullMod("fourteenth")) {
            ship.getVariant().addMod("CHM_hegemony_xiv");
        }
        if (ship.getVariant().hasHullMod("vayra_pirate_xiv")) {
            ship.getVariant().addMod("CHM_pirate_xiv");
        }
    }
    
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + ((Float) coom.get(HullSize.FRIGATE)).intValue();
        if (index == 1) return "" + ((Float) coom.get(HullSize.DESTROYER)).intValue();
        if (index == 2) return "" + ((Float) coom.get(HullSize.CRUISER)).intValue();
        if (index == 3) return "" + ((Float) coom.get(HullSize.CAPITAL_SHIP)).intValue();
        return null;
    }
}
