package data.scripts.hullmods;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.util.Misc;
import data.scripts.plugins.CommissionCheck;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CHM_commissioned extends BaseHullMod {
    public JSONArray spreadsheet = CommissionCheck.spreadsheet;
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        for (int i = 0; i < spreadsheet.length(); i++) {
            try {
                JSONObject row = spreadsheet.getJSONObject(i);
                String BigFactionEnergy = row.getString("faction_id");
                String BigHullMod = row.getString("hullmod_id");
                if (BigFactionEnergy.equals(Misc.getCommissionFactionId())) {
                    ship.getVariant().addMod(BigHullMod);
                    Global.getSoundPlayer().playUISound("leadership2", 1f, 1f);
                }
            } catch (JSONException ex) {
                Logger.getLogger(CHM_commissioned.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
	return !ship.getVariant().hasHullMod("CHM_commission2");
	}
    @Override
    public String getUnapplicableReason(ShipAPI ship) {
	return "You seem to have a hull mod that prohibits commissioned bonus.";
	}
}


