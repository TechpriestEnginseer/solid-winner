package data.scripts.hullmods;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;

public class CHM_alliance extends BaseHullMod {
    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
	return !ship.getVariant().hasHullMod("CHM_commission2") || !ship.getVariant().hasHullMod("CHM_commission");
	}
    @Override
    public String getUnapplicableReason(ShipAPI ship) {
	return "You cannot take on a commissioned crew! Stand yourself ready!";
	}
}


