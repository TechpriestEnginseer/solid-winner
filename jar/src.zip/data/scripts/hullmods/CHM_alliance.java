package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;

import static data.scripts.plugins.CommissionCheck.*;

public class CHM_alliance extends BaseHullMod {

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ShipVariantAPI var = ship.getVariant();

        var.addMod(ALL_DUMB);
        apply(var, true);
        var.removeMod(YOU_DO_ME);
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {

        return !ship.getVariant().hasHullMod(IN_YOUR_EYES) && !ship.getVariant().hasHullMod(ALL_DUMB);
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        if (ship.getVariant().hasHullMod(IN_YOUR_EYES)) return "You seem to have a hull mod that prohibits commissioned bonus.";
        if (ship.getVariant().hasHullMod(ALL_DUMB)) return "Hullmod already present";

        return "Something broke?";
    }
}

