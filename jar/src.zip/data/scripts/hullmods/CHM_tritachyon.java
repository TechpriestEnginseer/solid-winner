package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_tritachyon extends BaseHullMod {
    public static String based = "HIGH_TECH";
    public static String based2 = "Tri-Tachyon";
        
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (based.equals(ship.getHullStyleId()) || based2.equals(ship.getHullStyleId())) {
            ship.getVariant().addMod("CHM_tritachyon1"); 
        }   
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "High-Tech";
        if (index == 1) return based2;
        return null;
    }
}