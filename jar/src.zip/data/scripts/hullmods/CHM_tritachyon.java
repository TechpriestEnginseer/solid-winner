package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.awt.Color;

public class CHM_tritachyon extends BaseHullMod {
    public static final float OVERLOAD_REDUCTION = 0.2f;
    public static final float OHGODIMGONNA = 15f;

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
            stats.getOverloadTimeMod().modifyMult(id, 1f - OVERLOAD_REDUCTION);
            stats.getVentRateMult().modifyPercent(id, OHGODIMGONNA);
        }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) (OVERLOAD_REDUCTION * 100f) + "%";
        if (index == 0) return "" + (int) (OHGODIMGONNA) + "%";
        return null;
    }
    
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(135,206,255,255);
    }
}