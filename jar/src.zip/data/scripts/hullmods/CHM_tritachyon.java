package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_tritachyon extends BaseHullMod {
    public static final float OVERLOAD_REDUCTION = 0.2f;

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
            stats.getOverloadTimeMod().modifyMult(id, 1f - OVERLOAD_REDUCTION);
        }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) (OVERLOAD_REDUCTION * 100f) + "%";
        /*if (index == 1) return "High-Tech";
        if (index == 2) return based2;*/
        return null;
    }
}