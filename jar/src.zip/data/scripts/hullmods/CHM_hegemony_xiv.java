package data.scripts.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

public class CHM_hegemony_xiv extends BaseHullMod {
    private static final Map coom = new HashMap();
    static {
        coom.put(HullSize.FIGHTER, -5f);
        coom.put(HullSize.FRIGATE, -5f);
        coom.put(HullSize.DESTROYER, -20f);
        coom.put(HullSize.CRUISER, -35f);
        coom.put(HullSize.CAPITAL_SHIP, -50f);
        coom.put(HullSize.DEFAULT, -5f);
    }
    public static final float ARMOR_BONUS = 50f;

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getArmorBonus().modifyFlat(id, (Float) coom.get(hullSize));
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (ship.getVariant().hasHullMod("CHM_hegemony_xiv")) {
            ship.getVariant().removeMod("CHM_hegemony_xiv");
        }
    }
    
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) ARMOR_BONUS;
        return null;
    }
 
    @Override
    public Color getBorderColor() {
        return new Color(147, 102, 50, 0);
    }

    @Override
    public Color getNameColor() {
        return new Color(252,173,60,255);
    }
}
