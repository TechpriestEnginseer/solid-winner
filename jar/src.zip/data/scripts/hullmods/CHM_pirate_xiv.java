package data.scripts.hullmods;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class CHM_pirate_xiv extends BaseHullMod {
        public static final float ARMOR_BONUS = 20f;
        public static final float FLUX_HANDLING_MULT = 1.05f;
        @Override
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getArmorBonus().modifyFlat(id, ARMOR_BONUS);
                stats.getFluxCapacity().modifyMult(id, FLUX_HANDLING_MULT);
                stats.getFluxDissipation().modifyMult(id, FLUX_HANDLING_MULT);
	}
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
            if (!(ship.getVariant().hasHullMod("CHM_pirate") || ship.getVariant().hasHullMod("CHM_hegemony"))) {
                ship.getVariant().removeMod("CHM_pirate_xiv");
           }
    }	
      @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) ARMOR_BONUS;
                if (index == 1) return "" + (int) ((FLUX_HANDLING_MULT - 1f) * 100f) + "%";
		return null;  
	}
}